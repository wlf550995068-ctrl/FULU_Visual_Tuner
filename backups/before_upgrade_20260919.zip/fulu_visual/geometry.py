"""Shared shape mathematics, independent of window, storage or product semantics."""
import math

def dimensions(p):
    a=p['eye_width']*(1+p['stretch'])/2
    b=p['eye_height']*(1-p['squash'])*p['thickness']/2
    k=p['whole_bend']
    compression=1-(1-p['volume_preserve'])*(1-1/(1+.7*k*k))
    return a,b,p['corner_roundness']*min(a,b),k,compression

def deform(p,x,y):
    a,b,_,k,compression=dimensions(p)
    u=x/a
    arch=max(0.,1-u*u)
    profile=(1+p['center_bulge']*arch)*(1-p['end_taper']*u*u)*compression
    top=p['top_curve']*(1-p['squash'])
    bottom=p['bottom_curve']*(1-p['squash'])
    v=y*profile+(top+bottom)*.5*arch+y/(2*b)*(top-bottom)*arch
    if abs(k)<1e-4:
        return x,v
    radius=a/k
    angle=x/radius
    return (radius+v)*math.sin(angle),(radius+v)*math.cos(angle)-radius*math.cos(k)

def outline(p,samples=16):
    a,b,r,_,_=dimensions(p)
    points=[]
    angle=math.radians(p['tilt'])
    ca,sa=math.cos(angle),math.sin(angle)
    corners=((1,1,0),(-1,1,math.pi/2),(-1,-1,math.pi),(1,-1,3*math.pi/2))
    for index,(sx,sy,start) in enumerate(corners):
        for i in range(samples+1):
            theta=start+math.pi/2*i/samples
            x=sx*(a-r)+r*math.cos(theta)
            y=sy*(b-r)+r*math.sin(theta)
            x,y=deform(p,x,y)
            points.append((ca*x-sa*y,sa*x+ca*y))
        # Connect consecutive corners in perimeter order; these edges also bend.
        end=start+math.pi/2
        x0=sx*(a-r)+r*math.cos(end);y0=sy*(b-r)+r*math.sin(end)
        nx,ny,ns=corners[(index+1)%4]
        x1=nx*(a-r)+r*math.cos(ns);y1=ny*(b-r)+r*math.sin(ns)
        for i in range(1,samples*2):
            t=i/(samples*2)
            x=x0+(x1-x0)*t;y=y0+(y1-y0)*t
            x,y=deform(p,x,y)
            points.append((ca*x-sa*y,sa*x+ca*y))
    return points

def bounds(p):
    pts=outline(p)
    return min(x for x,y in pts),max(x for x,y in pts),min(y for x,y in pts),max(y for x,y in pts)

def mix_shape(a,b,u):
    if u<=0:return dict(a)
    if u>=1:return dict(b)
    return {key:a[key]+(b[key]-a[key])*u for key in a}

