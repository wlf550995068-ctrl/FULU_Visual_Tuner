# FULU Visual Tuner / Pose Editor

✓ 2026-09-17 增量升级：同一工作台右侧新增 **ACCENT / VISUAL ELEMENTS**，仅 QUESTION / EXCLAMATION。选择符号即可显示，支持直接拖动、尺寸/旋转/透明度、ENTER→HOLD→EXIT、独立 Reset 和同一 JSON 保存。启动方式仍是本目录 run.cmd，无需解压 ZIP。完整操作、文件清单与本轮测试见 [ACCENT_UPDATE.md](C:/Users/WYH/.codex/.chatgpt-projects/g-p-6aa2ad94e2b48191a6369e6cfd936bbc/FULU_Visual_GPU_Prototype/ACCENT_UPDATE.md)。

✓ 在原独立 Tuner 内升级。当前初始库只有 NORMAL、HAPPY。自定义 Pose 是工作台造型记录，不定义新的产品 BASE；Visual V2 正式分类不变。

✓ 保持 Python 3.12 + ModernGL + moderngl-window / pyglet + GLSL；同一窗口内使用已有 ImGui 控件。没有新增外部编辑软件，没有接主项目，没有修改 Light、Decision、Relationship、Memory、Reminder、Persistence、Runtime、RobotSession。

## 路径与启动

实际目录：C:/Users/WYH/.codex/.chatgpt-projects/g-p-6aa2ad94e2b48191a6369e6cfd936bbc/FULU_Visual_GPU_Prototype

双击 [run.cmd](C:/Users/WYH/.codex/.chatgpt-projects/g-p-6aa2ad94e2b48191a6369e6cfd936bbc/FULU_Visual_GPU_Prototype/run.cmd)，或在 PowerShell 执行：

~~~powershell
cd "C:/Users/WYH/.codex/.chatgpt-projects/g-p-6aa2ad94e2b48191a6369e6cfd936bbc/FULU_Visual_GPU_Prototype"
.\.venv\Scripts\python.exe simulator.py --window pyglet
~~~

现有环境已安装依赖，本轮无新增依赖。Python 3.12.10；ModernGL 5.12.0、moderngl-window 3.1.1、pyglet 2.1.16、imgui-bundle 1.6.3。完整版本在 [requirements-lock.txt](C:/Users/WYH/.codex/.chatgpt-projects/g-p-6aa2ad94e2b48191a6369e6cfd936bbc/FULU_Visual_GPU_Prototype/requirements-lock.txt)。窗口最低尺寸 1180×820；右侧参数区域可滚动。中文字体使用 Windows 微软雅黑。

首次复制到其他 Windows 电脑，可用 run.cmd 创建 Python 3.12 虚拟环境并安装锁定依赖。需要显卡 OpenGL 3.3。

## Pose Library

保存位置：[data/pose_library.json](C:/Users/WYH/.codex/.chatgpt-projects/g-p-6aa2ad94e2b48191a6369e6cfd936bbc/FULU_Visual_GPU_Prototype/data/pose_library.json)。一个 JSON 包含稳定 ID、显示名称、每个 Pose 独立 shape/defaults，以及工作台共享 Volume、Motion、A/B 选择。写入采用临时文件替换。

1. 在 POSE 下拉框选择当前编辑对象，预览切回这个静止检查姿态，暂停 A/B 播放。
2. **新建**：填写名称并确认，以 NORMAL 标准形状为起点。**复制**：复制当前 Pose 的形状，命名后成为独立记录。
3. 在 SHAPE 滑杆中调整。Whole Bend 是主体弯曲主控制；Top/Bottom Curve 是微调。
4. **保存此 Pose**：只把当前 Pose 的名称、形状、默认基线写入库。NORMAL/HAPPY 可分别保存。其他未保存 Pose/Volume/Motion 不会随之写入。
5. **加载此 Pose**：二次确认后，从磁盘恢复这个记录；可以 Undo。
6. **保存工作台 / S**：保存所有 Pose、删除与重命名、共享 Volume/Motion 和选择状态。重新启动会读回已保存库。
7. **重新加载库 / R**：确认后加载整个已保存工作台。可 Undo。
8. **删除**只对自定义 Pose 开放，需确认；随后 S 将删除写入磁盘。引用被删除 Pose 的 A/B 自动回到 NORMAL。删除可 Undo，但 Undo 后仍需 S 才更新磁盘。

NORMAL 可调、可保存、可复制，但名称受保护，不能删除。HAPPY 为当前另一个内置测试记录，也不可删除，可以重命名。重复名称、空名称、控制字符与 ## 会被拒绝。名称最长 40 字。

自定义记录的 Shape 默认值是创建/复制当时的快照；保存当前形状不会偷偷改写恢复基线。Shape 属于各 Pose；Volume/Motion 是工作台共享设置，不属于产品语义。

旧 [config.toml](C:/Users/WYH/.codex/.chatgpt-projects/g-p-6aa2ad94e2b48191a6369e6cfd936bbc/FULU_Visual_GPU_Prototype/config.toml) 保留不改，已迁移到 JSON；它不再是运行中的参数文件。另有 [迁移前备份](C:/Users/WYH/.codex/.chatgpt-projects/g-p-6aa2ad94e2b48191a6369e6cfd936bbc/FULU_Visual_GPU_Prototype/data/legacy_config_before_pose_editor.toml)。原有 NORMAL/HAPPY 参数尽量保留，共同边缘弧度迁入 Whole Bend。

## 任意 A/B 播放

底部 MOTION 选择 **Source A** 和 **Target B**。可以选择任意两个已创建的记录，不要求先保存。选择相同对象则不会出现形变。

- **SPACE / 自动往返**：开始或暂停 A→B→A 循环。
- **Pause**：冻结当前时刻。
- **Resume / P**：从当前时刻继续；P 也可暂停。不会重置时间轴。
- **Scrub**：拖动完整 A→B→A 时间轴，自动暂停。
- **Step / →**：暂停并前进一个配置的小步，默认 1/60 秒。
- 改选 Source/Target：重置到 A 并暂停，按 SPACE 开始新组合。
- Enter/Return Response 越大，转变越快。每次形变时长 = 6.64 / response 秒。
- 半周期 = max(target_interval, 进入形变时长, 返回形变时长)。提前抵达后停留至半周期结束；完整循环是两个半周期。
- 使用连续五次缓动，抵达与离开端点时速度/加速度归零。按实际经过时间推进，非手动拖动驱动。

组合会检查 101 个插值位置，拒绝明显折叠、过薄、交叉或越出安全区的形状。遇到限制，界面显示原因；可降低 Whole Bend/Thickness 或调整尺寸。

## SHAPE：每个 Pose 独立

坐标尺寸相对于设计画面高度；默认设计比例 16:9。间隔按变形后的主体边界定位，预览改变窗口大小不会改变形状比例。

| 参数 | 实际控制 |
|---|---|
| eye_width | 基础横向宽度，之后叠加 Stretch 与整体弯曲。 |
| eye_height | 基础纵向高度，之后叠加 Squash、Thickness 与几何鼓起。 |
| eye_gap | 两只眼睛变形后的最接近边界间隔。 |
| corner_roundness | 基础截面四角圆润度，随主体一起变形。 |
| whole_bend | 整个截面沿圆弧旋转/弯曲；正值中部上拱，负值下弯，单位弧度；上下边界与体积一起响应。 |
| thickness | 整体几何厚度系数。改变轮廓饱满度，并改变体积曲面的基准高度。 |
| center_bulge | 中段几何增厚，两端影响减小；F 平面模式也能看出轮廓改变。 |
| end_taper | 两端几何收缩比例；越大端部越细，非亮度遮罩。 |
| volume_preserve | 弯曲保形强度 0–1；1 保留原始截面厚度，0 随弯曲压缩。对直形不产生影响。当前是视觉面积近似保持，非真实 3D 体积守恒。 |
| top_curve | 上边界的小幅附加弧度，通过截面中心/厚度平滑分配。 |
| bottom_curve | 下边界的小幅附加弧度，不是内部笑线。 |
| tilt | 两眼镜像倾斜，单位度。 |
| squash | 纵向压缩比例。 |
| stretch | 横向拉伸比例。 |

## VOLUME：工作台共享

GLSL 在变形后的主体坐标中构造连续曲面高度场，通过屏幕空间导数计算曲面法线，再叠加宽域漫反射与连续滚暗。不是一个中心亮点，也不是只乘一个整体亮度系数。

| 参数 | 实际控制 |
|---|---|
| volume_depth | 曲面高度与法线坡度；越大侧面转折越明显。 |
| surface_roundness | 宽域圆润度：中心平缓区与向边缘转折的分布。独立于 Shape 圆角。 |
| center_fill | 宽中心基础亮度，不产生小亮点。 |
| bulge_influence | Shape 中 Center Bulge 对曲面高度的影响强度；本身不改变平面轮廓。 |
| side_falloff | 左右侧向外连续滚暗强度。 |
| bottom_falloff | 从中段到下缘连续滚暗强度。 |
| edge_falloff | 依据连续曲面高度靠近边缘的内部衰减，不叠加独立壳圈。 |
| edge_softness | 轮廓抗锯齿过渡宽度，约 0.5–1.5 像素；不是外部 halo。 |

当前采用临时中性灰，仅用于判断 2.5D 饱满度。无 specular 白色高光点、无瞳孔、无独立 rim、无外部 bloom。极端滚暗值可能视觉偏重，建议用 F 对比轮廓、再降低 Side/Bottom/Edge Falloff。

## MOTION 参数

| 参数 | 实际控制 |
|---|---|
| enter_response | A→B 形变响应速度，越大越快。 |
| return_response | B→A 形变响应速度，越大越快。 |
| target_interval | 每一程开始到下一程开始的最小间隔；不足以完成形变时自动延长。 |
| single_step_seconds | 每次 Step 的时间增量，默认 1/60 秒。 |

## Reset 与撤销范围

- **Restore Shape Defaults**：只恢复当前 Pose 的 Shape。内置 Pose 回到本版标准形状；自定义回到创建/复制基线。其他 Pose、Volume、Motion 不变。
- **Restore Volume Defaults**：只恢复共享的全部八个 Volume 参数，包括宽域圆润度。Shape/Motion 不变。
- **Restore Motion Defaults**：只恢复四个 Motion 参数。当前时间轴按归一化进度保留；Shape/Volume 不变。
- **Restore All Defaults**：弹窗二次确认；恢复所有 Pose 的 Shape 基线与共享 Volume/Motion/显示配置，时间轴回起点并暂停，F/G 关闭。不删除自定义记录，不改名称或 A/B 选择。窗口启动尺寸配置在下次启动应用。
- **Undo / Redo**：参数、创建/删除/重命名、分组恢复、确认后的全部恢复均可撤销/重做。连续拖动同一个滑杆视作一次操作，最多保留 80 次；播放时间和 F/G/V 是预览状态，不进入参数历史。保存不会清空历史；撤销保存后的修改需要再次 S 才写回磁盘。

## 键位 / Inspect

| 键 | 行为 |
|---|---|
| N / H | 选中 NORMAL / 内置 HAPPY 记录，停止 A/B 并进入形状编辑 |
| SPACE / P | 自动往返播放或暂停，从当前游标续播 |
| → | 暂停并前进一个小步 |
| V | 全局进入/退出 Inspect，即使名称输入框占用键盘也生效 |
| ESC（Inspect 内） | 只退出 Inspect，不关闭程序 |
| ESC（工作台） | 请求关闭；有未保存内容时询问保存/放弃/取消 |
| F | 纯轮廓/平面检查 |
| G | 安全区参考线 |
| S | 保存整个工作台 |
| Z / Y | Undo / Redo |
| R | 确认后重新加载整个库 |
| F12 | 保存工作台截图、眼睛截图和 JSON 参数快照到 captures |

Inspect 顶部另有返回按钮。进入/退出保持同一个 Renderer 和 Pose 参数，不重启窗口。按住 V 的重复按键被过滤，释放后再次按 V 才切换。根据“V 永远全局 toggle”要求，名称输入时 V 也会切换；名称含 V 可粘贴输入。

## 验证

~~~powershell
cd "C:/Users/WYH/.codex/.chatgpt-projects/g-p-6aa2ad94e2b48191a6369e6cfd936bbc/FULU_Visual_GPU_Prototype"
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
.\.venv\Scripts\python.exe verify_gpu.py
.\.venv\Scripts\python.exe simulator.py --window pyglet --smoke-seconds 15
~~~

窗口测试自动运行并退出，使用 test_output/pose_editor/smoke_library.json 隔离测试记录，不改真实 Pose 库。测试会注入 ImGui 鼠标事件及窗口键盘回调；不宣称人工鼠标肉眼验收。

结果与截图见 [TEST_REPORT.md](C:/Users/WYH/.codex/.chatgpt-projects/g-p-6aa2ad94e2b48191a6369e6cfd936bbc/FULU_Visual_GPU_Prototype/TEST_REPORT.md) 和 [test_output/pose_editor](C:/Users/WYH/.codex/.chatgpt-projects/g-p-6aa2ad94e2b48191a6369e6cfd936bbc/FULU_Visual_GPU_Prototype/test_output/pose_editor)。旧 test_output/tuner 与 captures/tuner_* 是历史证据，不代表本版。

## 本轮文件

修改：
- [simulator.py](C:/Users/WYH/.codex/.chatgpt-projects/g-p-6aa2ad94e2b48191a6369e6cfd936bbc/FULU_Visual_GPU_Prototype/simulator.py)：库与 A/B UI、分组 Reset、全局 Inspect、自动播放、测试入口。
- [fulu_visual/config.py](C:/Users/WYH/.codex/.chatgpt-projects/g-p-6aa2ad94e2b48191a6369e6cfd936bbc/FULU_Visual_GPU_Prototype/fulu_visual/config.py)：集中参数、独立持久化、迁移、验证、编辑历史。
- [fulu_visual/rig.py](C:/Users/WYH/.codex/.chatgpt-projects/g-p-6aa2ad94e2b48191a6369e6cfd936bbc/FULU_Visual_GPU_Prototype/fulu_visual/rig.py)：通用记录插值，左右眼定位，无 HAPPY 特殊逻辑。
- [fulu_visual/renderer.py](C:/Users/WYH/.codex/.chatgpt-projects/g-p-6aa2ad94e2b48191a6369e6cfd936bbc/FULU_Visual_GPU_Prototype/fulu_visual/renderer.py)：形变/体积参数绑定。
- [shaders/eye.frag](C:/Users/WYH/.codex/.chatgpt-projects/g-p-6aa2ad94e2b48191a6369e6cfd936bbc/FULU_Visual_GPU_Prototype/shaders/eye.frag)：圆弧整体形变、2.5D 高度场与中性明暗。
- [tests/test_rig.py](C:/Users/WYH/.codex/.chatgpt-projects/g-p-6aa2ad94e2b48191a6369e6cfd936bbc/FULU_Visual_GPU_Prototype/tests/test_rig.py)、[verify_gpu.py](C:/Users/WYH/.codex/.chatgpt-projects/g-p-6aa2ad94e2b48191a6369e6cfd936bbc/FULU_Visual_GPU_Prototype/verify_gpu.py)：新版行为/持久化/GPU 验证。
- [README.md](C:/Users/WYH/.codex/.chatgpt-projects/g-p-6aa2ad94e2b48191a6369e6cfd936bbc/FULU_Visual_GPU_Prototype/README.md)、[TEST_REPORT.md](C:/Users/WYH/.codex/.chatgpt-projects/g-p-6aa2ad94e2b48191a6369e6cfd936bbc/FULU_Visual_GPU_Prototype/TEST_REPORT.md)：当前说明与实测结果。

新增：
- [fulu_visual/geometry.py](C:/Users/WYH/.codex/.chatgpt-projects/g-p-6aa2ad94e2b48191a6369e6cfd936bbc/FULU_Visual_GPU_Prototype/fulu_visual/geometry.py)：共享变形、轮廓采样、边界计算。
- [fulu_visual/motion.py](C:/Users/WYH/.codex/.chatgpt-projects/g-p-6aa2ad94e2b48191a6369e6cfd936bbc/FULU_Visual_GPU_Prototype/fulu_visual/motion.py)：独立可暂停/续播/步进/拖动的循环时间轴。
- [data/pose_library.json](C:/Users/WYH/.codex/.chatgpt-projects/g-p-6aa2ad94e2b48191a6369e6cfd936bbc/FULU_Visual_GPU_Prototype/data/pose_library.json)：实际库，仅初始化 NORMAL、HAPPY。
- [data/legacy_config_before_pose_editor.toml](C:/Users/WYH/.codex/.chatgpt-projects/g-p-6aa2ad94e2b48191a6369e6cfd936bbc/FULU_Visual_GPU_Prototype/data/legacy_config_before_pose_editor.toml)：迁移前备份。
- [test_output/pose_editor](C:/Users/WYH/.codex/.chatgpt-projects/g-p-6aa2ad94e2b48191a6369e6cfd936bbc/FULU_Visual_GPU_Prototype/test_output/pose_editor)：本版报告、截图及隔离测试数据。

保留：run.cmd、frame_timer.py、eye.vert、依赖清单、原 config.toml。sources/ 和主项目未修改。

## 当前限制与下一步

当前是 2.5D 高度场与参数化轮廓，没有真实厚度网格、透视侧面或物理体积守恒。自动测试可以验证轮廓/时间轴/参数生效，不能替代你的视觉认可。强弯曲、高厚度、极端微调的组合受限，以避免折叠与交叉。

未做 Soft Azure 正式色相、电子光体最终材质、屏幕色域/gamma/AMOLED 标定；也未做其他 BASE、RESPONSE、PERFORMANCE、声音、灯光、主项目集成。

建议继续顺序：先 NORMAL 的 width/height/roundness/thickness/center_bulge；再 Volume Depth / Surface Roundness 与侧下缘滚暗；随后 HAPPY 的 Whole Bend / End Taper / Thickness；最后调 A/B 进入与返回响应和停留节奏。仍在这个工作台内完成验收。

